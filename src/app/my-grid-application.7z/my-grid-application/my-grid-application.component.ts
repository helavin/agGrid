import { Component, OnInit } from '@angular/core';
import { GridOptions } from 'ag-grid-community';
import { HttpClient, HttpResponseBase } from '@angular/common/http';
// import { Observable /*, Subject*/ } from 'rxjs';
// import { map, catchError } from 'rxjs/operators';
// import { ICar } from '../Car';
// import { Bloger } from '../bloger';
import { ReadService } from '../read.service';
import { ImgComponentComponent } from '../RendererComponents/img-component/img-component.component';
import { UrlComponentComponent } from '../RendererComponents/url-component/url-component.component';
import { TxtComponentComponent } from '../RendererComponents/txt-component/txt-component.component';
import { DateComponentComponent } from '../RendererComponents/date-component/date-component.component';


@Component({
    selector: 'app-my-grid-application',
    templateUrl: './my-grid-application.component.html',
    // styleUrls: ['./my-grid-application.component.scss']
})
export class MyGridApplicationComponent implements OnInit {
    private gridOptions: GridOptions;

    // columnDefs = [
    //     { headerName: 'Make', field: 'make', sortable: true, filter: true },
    //     { headerName: 'Model', field: 'model', sortable: true, filter: true },
    //     { headerName: 'Price', field: 'price', sortable: true, filter: true }
    // ];

    // statusCode: number;
    // private watch = 'https://www.youtube.com/watch?v=';
    rowData: any; // object[]; // any;
    private thumbnails = 'snippet.thumbnails.default.url';
    private publishedAt = 'snippet.publishedAt';
    private title = 'id.videoId';
    // rowData2: any;
    // public items = [];
    public blogers: Array<any>; // Bloger[];


    constructor(private readService: ReadService, private http: HttpClient) {
        this.gridOptions = {} as GridOptions;
        this.gridOptions.columnDefs = [
            {
                headerName: '', field: this.thumbnails,
                cellRendererFramework: ImgComponentComponent,
                width: 100, autoHeight: true
            },
            {
                headerName: 'Published on', field: this.publishedAt,
                // cellRendererFramework: DateComponentComponent,
                width: 160, sortable: true // resizable: true
            },
            {
                headerName: 'Video Title', field: this.title,
                cellRendererFramework: UrlComponentComponent,
                width: 300
            },
            {
                headerName: 'Description', field: 'snippet.description',
                cellRendererFramework: TxtComponentComponent,
                width: 200, autoHeight: true
            },

            // {
            //     headerName: 'ID', field: 'id', width: 100, pinned: 'right',
            //     // checkboxSelection: true
            //     // headerCheckboxSelection: true
            // },
            // {
            //     headerName: 'Value', field: 'value',
            //     pinned: 'right',
            //     sortable: true, filter: true,
            //     cellRendererFramework: RedComponentComponent, width: 100
            // },
        ];

        // console.log((this.rowData as Bloger[]));

        // (this.rowData as any[]).forEach(t => {
        //     this.gridOptions.rowData = [
        //         {
        //             publishedAt: this.rowData.items.snippet.publishedAt
        //         }
        //     ];
        // }
        // );

        // const watch = 'https://www.youtube.com/watch?v=';
        // this.gridOptions.rowData = [
        //     {
        //         publishedAt: this.rowData.items.snippet.publishedAt,
        //         // title: watch + this.rowData.id.videoId,
        //         // tslint:disable-next-line: max-line-length
        //         // description: this.rowData.snippet.description
        //         // id: 5, value: 10
        //     }
        // ];
    }

    ngOnInit() {
        // this.getData();
        this.rowData = this.readService.read();
    }

    formatDate(date: string) {

    }

    // getData() {
    //     this.readService.readT(this.rowData)
    //         .subscribe(
    //             // res => console.log(res),
    //             res => this.rowData = res, // as Bloger[],
    //             errorCode => console.log('errorCode:' + errorCode), // this.statusCode = errorCode,
    //             () => {
    //                 // console.log(this.rowData.items);
    //                 // this.blogers = this.rowData.items; // .push(this.rowData);
    //                 // console.log(this.blogers);
    //                 // this.rowData2 = this.rowData;
    //                 console.log(this.rowData);
    //             }
    //         );
    // }

}
